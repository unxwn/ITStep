# chronicle-project
Online service for your and your important people's notes
